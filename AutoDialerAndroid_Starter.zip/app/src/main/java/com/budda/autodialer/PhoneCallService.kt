package com.budda.autodialer

import android.telecom.Call
import android.telecom.InCallService

/**
 * Android's in-call integration point. This is only available when the user
 * grants the app the default-dialer role. A production build must add a full
 * in-call UI and carefully handle every Call state and OEM-specific behavior.
 */
class PhoneCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallStateHolder.currentCall = call
        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                CallStateHolder.state = state
            }
        })
    }

    override fun onCallRemoved(call: Call) {
        if (CallStateHolder.currentCall == call) CallStateHolder.currentCall = null
        super.onCallRemoved(call)
    }
}

object CallStateHolder {
    @Volatile var currentCall: Call? = null
    @Volatile var state: Int = Call.STATE_NEW
}
