package com.budda.autodialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    private val roleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestDialerRole()
        val needed = arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
        if (needed.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            permissionLauncher.launch(needed)
        }
        setContent {
            MaterialTheme {
                var rows by remember { mutableStateOf(DemoData.rows) }
                var index by remember { mutableIntStateOf(0) }
                var running by remember { mutableStateOf(false) }
                var status by remember { mutableStateOf("جاهز — استورد العملاء ثم ابدأ") }
                var outcome by remember { mutableStateOf("") }
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("مكالماتي العقارية", style = MaterialTheme.typography.headlineMedium)
                    Text("نسخة أولية — الاتصال المتتابع يتطلب تعيين التطبيق كتطبيق الهاتف الافتراضي.")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { requestDialerRole() }) { Text("تفعيل كتطبيق اتصال") }
                        OutlinedButton(onClick = { index = 0; running = false; status = "تم إيقاف الحملة" }) { Text("إيقاف") }
                    }
                    Text(status)
                    if (rows.isNotEmpty() && index in rows.indices) {
                        val c = rows[index]
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(c.name, style = MaterialTheme.typography.titleLarge)
                                Text(c.phone)
                                Text("المشروع: ${c.project}")
                                Text("ملاحظات: ${c.notes}")
                            }
                        }
                        Button(onClick = {
                            running = true
                            placeCall(c.phone)
                            status = "جاري الاتصال بـ ${c.name}"
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "إعادة الاتصال بالعميل" else "Start — اتصال") }
                        Text("العميل ${index + 1} من ${rows.size}")
                        Text("تسجيل نتيجة المكالمة")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("مهتم", "معاودة اتصال", "غير مهتم", "رقم غلط").forEach { result ->
                                OutlinedButton(onClick = {
                                    outcome = result
                                    rows = rows.toMutableList().also { it[index] = c.copy(result = result) }
                                    if (index < rows.lastIndex) index++ else { running = false; status = "انتهت قائمة العملاء" }
                                }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(result) }
                            }
                        }
                    } else Text("لا يوجد عملاء في القائمة")
                    Text("قائمة العملاء")
                    LazyColumn { items(rows) { Text("${it.name} — ${it.phone} — ${it.result}") } }
                }
            }
        }
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            }
        }
    }

    private fun placeCall(number: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return
        val telecom = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        telecom.placeCall(Uri.fromParts("tel", number, null), Bundle())
    }
}
