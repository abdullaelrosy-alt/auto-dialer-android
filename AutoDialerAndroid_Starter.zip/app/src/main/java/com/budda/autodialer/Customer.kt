package com.budda.autodialer

data class Customer(
    val name: String,
    val phone: String,
    val project: String = "",
    val notes: String = "",
    val result: String = "لم يتم الاتصال"
)

object DemoData {
    val rows = listOf(
        Customer("عميل تجريبي 1", "01000000001", "The Five", "مهتم بوحدة سكنية"),
        Customer("عميل تجريبي 2", "01000000002", "Rivali", "يفضل معاودة الاتصال مساءً")
    )
}
